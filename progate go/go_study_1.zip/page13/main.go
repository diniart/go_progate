package main

func main() {
    x := 7 * 10
    y := 5 * 6
    
    // Buatlah sebuah pernyataan `if` untuk ketika nilai x sama dengan 70
    if x== 70{
        println("x samadengan 70")
    }
    
    // Buatlah sebuah pernyataan `if` untuk ketika nilai y tidak sama dengan 40
    if y != 40 {
        println("y tidak sama dengan 40")
    }
    
}
