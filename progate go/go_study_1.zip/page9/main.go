package main

func main() {
    // Deklarasikan variable `message` dan tetapkan "Hello, world" pada-nya
    	var message  = "Hello, world"
    
    // Deklarasikan variable `number` dan tetapkan `100` pada-nya 
    	var number  = 100
    
    // Cetak nilai dari `message` dan `number`
    println(message, number)
    
    
}
