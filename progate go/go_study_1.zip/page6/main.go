package main

func main() {
    // Gabungkan string-string "Hello, " dan "world", lalu cetak
    println("Hello, "+"world")
    
    // Gabungkan string-string "38" dan "19", lalu cetak
    println("38"+"19")
    
    // Cetak penjumlahan 38 dan 19
    println(38+19)
    

}
