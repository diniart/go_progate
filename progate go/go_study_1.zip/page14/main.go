package main

func main() {
    money := 100
    price := 200
    
    // Tambahkan sebuah pernyataan `else`
    if money >= price {
        println("Anda bisa membeli produk ini")
    } else {
        println("Anda tidak memiliki cukup uang")
    }
    
}
