package main

func main() {
    // Cetak angka 7
    
    println(7)
    
    
    // Cetak penjumlahan dari 9 dan 3
     println(9+3)
    
    // Cetak "9 + 3" sebagai sebuah string
    
    println("9 + 3")
}
