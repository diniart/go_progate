package main

func main() {
    x := 123
    y := 5 * 6
    
    // Ketika x lebih besar atau sama dengan 100, cetak "x lebih besar atau sama dengan 100"
if x>=100{
    println("x lebih besar atau sama dengan 100")
    
}
    
    // Ketika y kurang dari 40, cetak "y kurang dari 40"
    if y<40 {
        println("y kurang dari 40")
    }
    
    
}
