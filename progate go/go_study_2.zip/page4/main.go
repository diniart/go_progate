package main

import "fmt"

func main() {
    month := 9
    day := 5
    
    // Cetak "Tanggal hari ini adalah ____/____" menggunakan fmt.Printf
    fmt.Printf("Tanggal hari ini adalah %d/%d",month,day)
    
}
