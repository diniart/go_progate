package main

import "fmt"

func main() {
    // Cetak setiap integer mulai dari 1 hingga 100
    for i:=1;i<=100;i++{
        fmt.Println(i)
    }
    
}
